package org.cloudburstmc.protocol.bedrock.codec.netease.serializer;

import io.netty.buffer.ByteBuf;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.v407.serializer.PlayerEnchantOptionsSerializer_v407;
import org.cloudburstmc.protocol.bedrock.data.inventory.EnchantData;
import org.cloudburstmc.protocol.bedrock.data.inventory.EnchantOptionData;
import org.cloudburstmc.protocol.bedrock.util.VarInts;

import java.util.List;

public class PlayerEnchantOptionsSerializer_v407_NetEase extends PlayerEnchantOptionsSerializer_v407 {
    public static final PlayerEnchantOptionsSerializer_v407_NetEase INSTANCE = new PlayerEnchantOptionsSerializer_v407_NetEase();

    @Override
    protected void writeOption(ByteBuf buffer, BedrockCodecHelper helper, EnchantOptionData option) {
        VarInts.writeUnsignedInt(buffer, option.cost());
        buffer.writeIntLE(option.primarySlot());
        helper.writeArray(buffer, option.enchants0(), (b, enchant) -> serializeEnchant(b, enchant, helper));
        helper.writeArray(buffer, option.enchants1(), (b, enchant) -> serializeEnchant(b, enchant, helper));
        helper.writeArray(buffer, option.enchants2(), (b, enchant) -> serializeEnchant(b, enchant, helper));
        helper.writeArray(buffer, option.enchantsCustom(), (b, enchant) -> serializeEnchant(b, enchant, helper));
        helper.writeString(buffer, option.enchantName());
        VarInts.writeUnsignedInt(buffer, option.enchantNetId());
    }

    @Override
    protected EnchantOptionData readOption(ByteBuf buffer, BedrockCodecHelper helper) {
        int cost = VarInts.readUnsignedInt(buffer);
        int primarySlot = buffer.readIntLE();
        List<EnchantData> enchants0 = new ObjectArrayList<>();
        helper.readArray(buffer, enchants0, b -> deserializeEnchant(b, helper));
        List<EnchantData> enchants1 = new ObjectArrayList<>();
        helper.readArray(buffer, enchants1, b -> deserializeEnchant(b, helper));
        List<EnchantData> enchants2 = new ObjectArrayList<>();
        helper.readArray(buffer, enchants2, b -> deserializeEnchant(b, helper));
        List<EnchantData> enchantsCustom = new ObjectArrayList<>();
        helper.readArray(buffer, enchantsCustom, b -> deserializeEnchant(b, helper));
        String enchantName = helper.readString(buffer);
        int enchantNetId = VarInts.readUnsignedInt(buffer);
        return new EnchantOptionData(cost, primarySlot, enchants0, enchants1, enchants2, enchantsCustom, enchantName, enchantNetId);
    }

    protected void serializeEnchant(ByteBuf buffer, EnchantData enchant, BedrockCodecHelper helper) {
        buffer.writeByte(enchant.type());
        buffer.writeByte(enchant.level());
        helper.writeString(buffer, enchant.modEnchantIdentifier());
    }

    protected EnchantData deserializeEnchant(ByteBuf buffer, BedrockCodecHelper helper) {
        int type = buffer.readUnsignedByte();
        int level = buffer.readUnsignedByte();
        String modEnchantIdentifier = helper.readString(buffer);
        return new EnchantData(type, level, modEnchantIdentifier);
    }
}
