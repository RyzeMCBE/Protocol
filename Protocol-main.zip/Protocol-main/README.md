# Protocol

[![License](https://img.shields.io/badge/license-apache%202.0-blue.svg)](LICENSE)
[![Maven Central](https://img.shields.io/maven-central/v/org.allaymc.protocol/bedrock-connection?label=bedrock-connection)](https://central.sonatype.com/artifact/org.allaymc.protocol/bedrock-connection)

A protocol library for Minecraft: Bedrock Edition with multi-version codec support.

This project is a hard fork of [CloudburstMC/Protocol](https://github.com/CloudburstMC/Protocol).

## Modules

| Module               | Description                                                                                                          |
|:---------------------|:---------------------------------------------------------------------------------------------------------------------|
| `bedrock-codec`      | Bedrock packet definitions, serializers, helpers, and version-specific codec constants such as `Bedrock_v944.CODEC`. |
| `bedrock-connection` | Netty + RakNet connection support, including peers, sessions, compression, and encryption.                           |

Published artifacts use the `org.allaymc.protocol` group, while the Java packages remain under `org.cloudburstmc.protocol`.

## Adding to Your Project

Choose the smallest module that matches your use case:

- `org.allaymc.protocol:bedrock-codec` if you only need packet serialization, deserialization, and version-specific codecs.
- `org.allaymc.protocol:bedrock-connection` if you also need the Netty/RakNet transport and session layer.

```kts
repositories {
    mavenCentral()
    maven("https://repo.opencollab.dev/maven-releases/")
    maven("https://repo.opencollab.dev/maven-snapshots/")
}

dependencies {
    implementation("org.allaymc.protocol:bedrock-connection:<version>")
}
```

## Supported Versions

This library supports multiple Bedrock protocol versions. The table below lists the codec class for each supported Minecraft version:

<details>
<summary><b>Supported Versions</b></summary>

|        Class         |      Minecraft Version      |
|:--------------------:|:---------------------------:|
|     Bedrock_v291     |            1.7.0            |
|     Bedrock_v313     |            1.8.0            |
|     Bedrock_v332     |            1.9.0            |
|     Bedrock_v340     |           1.10.0            |
|     Bedrock_v354     |           1.11.0            |
|     Bedrock_v361     |           1.12.0            |
|     Bedrock_v388     |           1.13.0            |
|     Bedrock_v389     |      1.14.0 - 1.14.50       |
|     Bedrock_v390     |           1.14.60           |
|     Bedrock_v407     |      1.16.0 - 1.16.10       |
|     Bedrock_v408     |           1.16.20           |
|     Bedrock_v419     |          1.16.100           |
|     Bedrock_v422     |     1.16.200 - 1.16.201     |
|     Bedrock_v428     |          1.16.210           |
|     Bedrock_v431     |          1.16.220           |
|     Bedrock_v440     |           1.17.0            |
|     Bedrock_v448     |      1.17.10 - 1.17.11      |
|     Bedrock_v465     |      1.17.30 - 1.17.34      |
|     Bedrock_v471     |      1.17.40 - 1.17.41      |
|     Bedrock_v475     |           1.18.0            |
|     Bedrock_v486     |           1.18.10           |
|     Bedrock_v503     |           1.18.30           |
|     Bedrock_v527     |           1.19.0            |
|     Bedrock_v534     |           1.19.10           |
|     Bedrock_v544     |           1.19.20           |
|     Bedrock_v545     |           1.19.21           |
|     Bedrock_v554     |           1.19.30           |
|     Bedrock_v557     |           1.19.40           |
|     Bedrock_v560     |           1.19.50           |
|     Bedrock_v567     |           1.19.60           |
|     Bedrock_v568     |      1.19.62 - 1.19.63      |
|     Bedrock_v575     |      1.19.70 - 1.19.73      |
|     Bedrock_v582     |      1.19.80 - 1.19.83      |
|     Bedrock_v589     |      1.20.0  - 1.20.1       |
|     Bedrock_v594     |      1.20.10 - 1.20.15      |
|     Bedrock_v618     |      1.20.30 - 1.20.32      |
|     Bedrock_v622     |      1.20.40 - 1.20.41      |
|     Bedrock_v630     |      1.20.50 - 1.20.51      |
| Bedrock_v630_NetEase | 1.20.50 - 1.20.51 (NetEase) |
|     Bedrock_v649     |           1.20.60           |
|     Bedrock_v662     |           1.20.70           |
|     Bedrock_v671     |           1.20.80           |
|     Bedrock_v685     |           1.21.0            |
|     Bedrock_v686     |           1.21.2            |
| Bedrock_v686_NetEase |      1.21.2 (NetEase)       |
|     Bedrock_v712     |           1.21.20           |
|     Bedrock_v729     |           1.21.30           |
|     Bedrock_v748     |           1.21.40           |
|     Bedrock_v766     |           1.21.50           |
| Bedrock_v766_NetEase |      1.21.50 (NetEase)      |
|     Bedrock_v776     |           1.21.60           |
|     Bedrock_v786     |           1.21.70           |
|     Bedrock_v800     |           1.21.80           |
|     Bedrock_v818     |      1.21.90 - 1.21.92      |
|     Bedrock_v819     |      1.21.93 - 1.21.94      |
| Bedrock_v819_NetEase | 1.21.93 - 1.21.94 (NetEase) |
|     Bedrock_v827     |     1.21.100 - 1.21.101     |
|     Bedrock_v844     |     1.21.111 - 1.21.114     |
|     Bedrock_v859     |     1.21.120 - 1.21.123     |
|     Bedrock_v860     |          1.21.124           |
|     Bedrock_v897     |     1.21.130 - 1.21.132     |
|     Bedrock_v924     |       1.26.0 - 1.26.3       |
|     Bedrock_v944     |           1.26.10           |
|     Bedrock_v975     |           1.26.20           |

</details>
